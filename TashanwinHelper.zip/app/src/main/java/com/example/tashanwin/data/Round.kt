package com.example.tashanwin.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "rounds")
data class Round(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val result: String, // "B" or "S"
    val timestamp: Long = System.currentTimeMillis(),
    val source: String = "manual" // "manual" or "sim"
)
