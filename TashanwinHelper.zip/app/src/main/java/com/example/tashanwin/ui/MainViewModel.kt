package com.example.tashanwin.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.tashanwin.data.AppDatabase
import com.example.tashanwin.data.Round
import com.example.tashanwin.util.predictFrom
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getInstance(application)
    private val dao = db.roundDao()

    val roundsFlow: StateFlow<List<Round>> = dao.getAllFlow()
        .map { it.sortedByDescending { r -> r.timestamp } }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun addResult(symbol: String, source: String = "manual") {
        viewModelScope.launch(Dispatchers.IO) {
            dao.insert(Round(result = symbol, source = source))
        }
    }

    fun undoLast() {
        viewModelScope.launch(Dispatchers.IO) {
            val last = dao.getLastN(1).firstOrNull()
            if (last != null) dao.deleteById(last.id)
        }
    }

    fun clearAll() {
        viewModelScope.launch(Dispatchers.IO) { dao.deleteAll() }
    }

    suspend fun getLastN(n: Int): List<Round> = dao.getLastN(n)

    suspend fun predictNextFromLast5(): Pair<String?, String> {
        val last5 = dao.getLastN(5).map { it.result }
        return predictFrom(last5)
    }
}
