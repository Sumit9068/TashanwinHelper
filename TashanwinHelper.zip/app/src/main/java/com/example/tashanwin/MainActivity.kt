package com.example.tashanwin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.tashanwin.ui.screens.HomeScreen
import com.example.tashanwin.ui.MainViewModel
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import kotlinx.coroutines.*

class MainActivity : ComponentActivity() {
    private var simulatorJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainViewModel = viewModel()
            Surface(color = MaterialTheme.colors.background) {
                HomeScreen(vm = vm, onToggleSimulator = { toggle ->
                    if (toggle) startSimulator(vm) else stopSimulator()
                })
            }
        }
    }

    private fun startSimulator(vm: MainViewModel) {
        simulatorJob?.cancel()
        simulatorJob = CoroutineScope(Dispatchers.Main).launch {
            while (isActive) {
                val result = if (Math.random() > 0.5) "B" else "S"
                vm.addResult(result, "sim")
                delay(60000) // 60 seconds
            }
        }
    }

    private fun stopSimulator() {
        simulatorJob?.cancel()
    }
}
