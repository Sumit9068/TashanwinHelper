package com.example.tashanwin.util

fun predictFrom(last5: List<String>): Pair<String?, String> {
    if (last5.isEmpty()) return Pair(null, "Not enough data")
    val seq = last5.take(5).reversed()
    val s = seq.joinToString("")

    fun majorityOpposite(seq: String): String {
        val bCount = seq.count { it == 'B' }
        val sCount = seq.count { it == 'S' }
        return if (bCount > sCount) "S" else if (sCount > bCount) "B" else (if (seq.last() == 'B') "S" else "B")
    }

    if (s.all { it == 'B' }) return Pair("S", "High (5 in a row)")
    if (s.all { it == 'S' }) return Pair("B", "High (5 in a row)")

    val bCount = s.count { it == 'B' }
    val sCount = s.count { it == 'S' }
    if (bCount == 4 || sCount == 4) {
        return Pair(majorityOpposite(s), "Medium (4 of 5)")
    }

    val alt1 = generateSequence(0) { it + 1 }.take(s.length).map { if (it % 2 == 0) 'B' else 'S' }.joinToString("")
    val alt2 = generateSequence(0) { it + 1 }.take(s.length).map { if (it % 2 == 0) 'S' else 'B' }.joinToString("")
    if (s == alt1 || s == alt2) {
        val next = if (s.last() == 'B') "S" else "B"
        return Pair(next, "Medium (alternating)")
    }

    val last = s.last().toString()
    val suggestion = if (last == "B") "S" else "B"
    return Pair(suggestion, "Low (mixed pattern)")
}
