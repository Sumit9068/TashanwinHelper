package com.example.tashanwin.ui.screens

import androidx.compose.runtime.*
import androidx.compose.material.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.tashanwin.data.Round
import com.example.tashanwin.ui.MainViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(vm: MainViewModel, onToggleSimulator: (Boolean) -> Unit) {
    val rounds by vm.roundsFlow.collectAsState()
    val scope = rememberCoroutineScope()
    var suggestion by remember { mutableStateOf<Pair<String?, String>>(Pair(null, "")) }
    var simOn by remember { mutableStateOf(false) }

    fun refreshPrediction() {
        scope.launch {
            suggestion = vm.predictNextFromLast5()
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Tashanwin Helper") })
    }) { padding ->
        Column(modifier = Modifier.padding(16.dp).padding(padding)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Button(onClick = { vm.addResult("B") }) { Text("Add B") }
                Button(onClick = { vm.addResult("S") }) { Text("Add S") }
                Button(onClick = { vm.undoLast() }) { Text("Undo") }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Last 5:", style = MaterialTheme.typography.subtitle1)
                Button(onClick = { refreshPrediction() }) { Text("Predict") }
            }

            Spacer(modifier = Modifier.height(6.dp))

            val last5 = rounds.take(5)
            Text(text = last5.reversed().joinToString(" ") { it.result }, style = MaterialTheme.typography.h6)

            Spacer(modifier = Modifier.height(8.dp))

            if (suggestion.first != null) {
                Card(elevation = 4.dp, modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Suggested Next: ${'$'}{suggestion.first}", style = MaterialTheme.typography.h5)
                        Text("Confidence: ${'$'}{suggestion.second}", style = MaterialTheme.typography.body2)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text("Practice Mode:")
                Spacer(modifier = Modifier.width(6.dp))
                Button(onClick = {
                    simOn = !simOn
                    onToggleSimulator(simOn)
                }) {
                    Text(if (simOn) "Stop" else "Start")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text("History", style = MaterialTheme.typography.h6)
            Spacer(modifier = Modifier.height(6.dp))

            LazyColumn {
                items(rounds) { r ->
                    RoundRow(r)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Button(onClick = { vm.clearAll() }) { Text("Clear All (Reset)") }
        }
    }
}

@Composable
fun RoundRow(round: Round) {
    val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(round.result)
        Text(sdf.format(Date(round.timestamp)))
    }
}
