package com.example.tashanwin.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface RoundDao {
    @Insert
    suspend fun insert(round: Round): Long

    @Query("SELECT * FROM rounds ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getLastN(limit: Int): List<Round>

    @Query("SELECT * FROM rounds ORDER BY timestamp DESC")
    fun getAllFlow(): kotlinx.coroutines.flow.Flow<List<Round>>

    @Query("DELETE FROM rounds")
    suspend fun deleteAll()

    @Query("DELETE FROM rounds WHERE id = :id")
    suspend fun deleteById(id: Long)
}
